<?php
	$conn = mysqli_connect("localhost","root","JAMES1995","tigom");
?>